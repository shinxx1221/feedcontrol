import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  bool isFeeding = false;
  int feedProgress = 0;
  double feedDuration = 30.0;
  Timer? feedTimer;
  List<TimeOfDay> scheduledTimes = [];
  bool automaticFeeding = false;

  @override
  void initState() {
    super.initState();
    Timer.periodic(const Duration(minutes: 1), (timer) {
      if (!isFeeding && automaticFeeding) {
        checkAndStartScheduledFeed();
      }
    });
  }

  void checkAndStartScheduledFeed() {
    final now = TimeOfDay.now();
    for (var time in scheduledTimes) {
      if (now.hour == time.hour && now.minute == time.minute) {
        startFeeding();
        break;
      }
    }
  }

  void startFeeding() {
    setState(() {
      isFeeding = true;
      feedProgress = 0;
    });

    sendCommandToFirebase("FEED");

    feedTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        feedProgress += (100 / feedDuration).round();
        if (feedProgress >= 100) {
          timer.cancel();
          isFeeding = false;
          feedProgress = 100;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Feeding completed!')),
          );
        }
      });
    });
  }

  void stopFeeding() {
    feedTimer?.cancel();
    setState(() {
      isFeeding = false;
      feedProgress = 0;
    });
  }

  void sendCommandToFirebase(String command) async {
    final ref = FirebaseDatabase.instance.ref('commands');
    final timestamp = DateTime.now().toIso8601String();
    await ref.push().set({
      'type': command,
      'timestamp': timestamp,
    });
  }

  Future<void> pickScheduleTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (picked != null) {
      setState(() {
        scheduledTimes.add(picked);
      });

      final now = DateTime.now();
      final scheduledDateTime = DateTime(
        now.year,
        now.month,
        now.day,
        picked.hour,
        picked.minute,
      );

      final ref = FirebaseDatabase.instance.ref('schedules');
      await ref.push().set({
        'type': 'FEED',
        'scheduled_at': scheduledDateTime.toIso8601String(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Feeding scheduled at ${picked.format(context)}')),
      );
    }
  }

  void removeScheduledTime(int index) {
    setState(() {
      scheduledTimes.removeAt(index);
    });
  }

  @override
  void dispose() {
    feedTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final feedButtonColor = isFeeding ? Colors.red : Colors.green;
    final feedButtonText = isFeeding ? 'Stop Dispense' : 'Feed Now';

    return Scaffold(
      backgroundColor: const Color(0xFFFFF9E6), // light yellow
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: const Text('Feed Control'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: const Color(0xFFF9F6FF),
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4)),
                ],
              ),
              child: Column(
                children: [
                  const Text(
                    'CURRENT FEED STATUS',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.orange,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                        children: [
                          const Text('Next Feeding', style: TextStyle(fontSize: 14)),
                          Text(
                            scheduledTimes.isEmpty
                                ? 'Not scheduled'
                                : scheduledTimes.first.format(context),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Feed Amount', style: TextStyle(fontSize: 14)),
                          Text(
                            '${(feedDuration).toStringAsFixed(1)} g',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),

            const Text(
              'FEEDING SCHEDULE',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.orange,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 8),

            if (scheduledTimes.isEmpty)
              const Text(
                'No feeding times scheduled',
                style: TextStyle(color: Colors.grey, fontSize: 16),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: scheduledTimes.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(
                      scheduledTimes[index].format(context),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => removeScheduledTime(index),
                    ),
                  );
                },
              ),

            const SizedBox(height: 16),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: pickScheduleTime,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: const Text(
                    'Add Schedule',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (isFeeding) {
                      stopFeeding();
                    } else {
                      startFeeding();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: feedButtonColor,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text(
                    feedButtonText,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),
            const Text(
              'FEED AMOUNT (grams)',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.orange,
                fontSize: 16,
              ),
            ),
            Slider(
              activeColor: Colors.orange,
              value: feedDuration,
              min: 10,
              max: 200,
              divisions: 19,
              label: '${feedDuration.round()} g',
              onChanged: (value) {
                setState(() => feedDuration = value);
              },
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Automatic Feeding',
                  style: TextStyle(fontSize: 16),
                ),
                Switch(
                  value: automaticFeeding,
                  onChanged: (val) {
                    setState(() {
                      automaticFeeding = val;
                    });
                  },
                  activeColor: Colors.orange,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class WaterPage extends StatefulWidget {
  const WaterPage({Key? key}) : super(key: key);

  @override
  State<WaterPage> createState() => _WaterPageState();
}

class _WaterPageState extends State<WaterPage> {
  double waterDuration = 30;
  bool isAutomaticWatering = false;
  bool isWatering = false;
  List<TimeOfDay> scheduleList = [];

  void addSchedule() async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (pickedTime != null && !scheduleList.contains(pickedTime)) {
      setState(() {
        scheduleList.add(pickedTime);
        scheduleList.sort((a, b) =>
        a.hour.compareTo(b.hour) != 0 ? a.hour.compareTo(b.hour) : a.minute.compareTo(b.minute));
      });
    }
  }

  void removeSchedule(int index) {
    setState(() {
      scheduleList.removeAt(index);
    });
  }

  void toggleWatering() {
    setState(() {
      isWatering = !isWatering;
      // Add BLE or Firebase command if needed
    });
  }

  @override
  Widget build(BuildContext context) {
    final nextWatering = scheduleList.isEmpty
        ? 'Not scheduled'
        : DateFormat.jm().format(
      DateTime(
        DateTime.now().year,
        DateTime.now().month,
        DateTime.now().day,
        scheduleList.first.hour,
        scheduleList.first.minute,
      ),
    );

    return Scaffold(
      backgroundColor: const Color(0xFFE7F5FE),
      appBar: AppBar(
        title: const Text("Water Control"),
        backgroundColor: const Color(0xFF2196F3),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Water Status Card
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              elevation: 4,
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        const Text("Next Watering", style: TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text(
                          nextWatering,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        const Text("Duration", style: TextStyle(fontSize: 16)),
                        const SizedBox(height: 8),
                        Text(
                          "${waterDuration.toStringAsFixed(1)} sec",
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "WATERING SCHEDULE",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.blue),
              ),
            ),
            const SizedBox(height: 12),

            // Schedule List
            scheduleList.isEmpty
                ? const Text(
              "No watering times scheduled",
              style: TextStyle(color: Colors.grey, fontSize: 16),
            )
                : Column(
              children: scheduleList.asMap().entries.map((entry) {
                final index = entry.key;
                final time = entry.value;
                return ListTile(
                  title: Text(
                    time.format(context),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => removeSchedule(index),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 20),

            // Buttons Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Add Schedule
                ElevatedButton(
                  onPressed: addSchedule,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                  child: const Text(
                    "Add Schedule",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),

                // Toggle Watering
                ElevatedButton(
                  onPressed: toggleWatering,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isWatering ? Colors.red : Colors.green,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                  child: Text(
                    isWatering ? "Stop Dispense" : "Water Now",
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),

            // Duration Slider
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "WATER DURATION (seconds)",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.blue),
              ),
            ),
            Slider(
              value: waterDuration,
              min: 5,
              max: 60,
              divisions: 11,
              label: "${waterDuration.round()}",
              onChanged: (value) {
                setState(() {
                  waterDuration = value;
                });
              },
              activeColor: Colors.blue,
              thumbColor: Colors.blueAccent,
            ),

            const SizedBox(height: 10),

            // Water Duration Indicator Card
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              color: Colors.lightBlue.shade50,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.water_drop, color: Colors.blue),
                    const SizedBox(width: 10),
                    const Text(
                      "Duration:",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      "${waterDuration.round()} seconds",
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 10),

            // Automatic Watering Toggle
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Automatic Watering",
                  style: TextStyle(fontSize: 16),
                ),
                Switch(
                  value: isAutomaticWatering,
                  onChanged: (value) {
                    setState(() {
                      isAutomaticWatering = value;
                    });
                  },
                  activeColor: Colors.blue,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

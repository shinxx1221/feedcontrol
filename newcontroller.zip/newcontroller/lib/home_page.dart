import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

import 'feed_page.dart';
import 'water_page.dart';
import 'vitamins_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void sendCommandAndNavigate(String type, BuildContext context, Widget nextPage) async {
    try {
      final DatabaseReference ref = FirebaseDatabase.instance.ref('commands');
      final timestamp = DateTime.now().toIso8601String();

      await ref.push().set({
        'type': type,
        'timestamp': timestamp,
      });

      if (!context.mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$type command sent')),
      );

      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => nextPage),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send command: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chicken Feeder Controller')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton.icon(
                icon: const Icon(Icons.restaurant_menu), // Built-in icon
                label: const Text(
                  'FEED',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 18,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  minimumSize: const Size.fromHeight(60),
                ),
                onPressed: () =>
                    sendCommandAndNavigate('FEED', context, const FeedPage()),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.water), // Built-in icon
                label: const Text(
                  'WATER',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 18,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  minimumSize: const Size.fromHeight(60),
                ),
                onPressed: () =>
                    sendCommandAndNavigate('WATER', context, const WaterPage()),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.healing), // Built-in icon
                label: const Text(
                  'VITAMIN',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 18,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  minimumSize: const Size.fromHeight(60),
                ),
                onPressed: () =>
                    sendCommandAndNavigate('VITAMIN', context, const VitaminPage()),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class VitaminPage extends StatefulWidget {
  const VitaminPage({super.key});

  @override
  State<VitaminPage> createState() => _VitaminPageState();
}

class _VitaminPageState extends State<VitaminPage> {
  bool isDispensing = false;
  double dose = 1.0;
  Timer? vitaminTimer;
  List<TimeOfDay> scheduledTimes = [];
  bool automaticDispensing = false;

  @override
  void initState() {
    super.initState();
    Timer.periodic(const Duration(minutes: 1), (timer) {
      if (!isDispensing && automaticDispensing) {
        checkAndStartScheduledDispense();
      }
    });
  }

  void checkAndStartScheduledDispense() {
    final now = TimeOfDay.now();
    for (var time in scheduledTimes) {
      if (now.hour == time.hour && now.minute == time.minute) {
        startDispensing();
        break;
      }
    }
  }

  void startDispensing() {
    setState(() {
      isDispensing = true;
    });

    sendCommandToFirebase("VITAMIN");

    vitaminTimer = Timer(const Duration(seconds: 5), () {
      setState(() {
        isDispensing = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vitamin dispensing completed!')),
      );
    });
  }

  void stopDispensing() {
    vitaminTimer?.cancel();
    setState(() {
      isDispensing = false;
    });
  }

  void sendCommandToFirebase(String command) async {
    final ref = FirebaseDatabase.instance.ref('commands');
    final timestamp = DateTime.now().toIso8601String();
    await ref.push().set({
      'type': command,
      'timestamp': timestamp,
    });
  }

  Future<void> pickScheduleTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (picked != null) {
      setState(() {
        scheduledTimes.add(picked);
      });

      final now = DateTime.now();
      final scheduledDateTime = DateTime(
        now.year,
        now.month,
        now.day,
        picked.hour,
        picked.minute,
      );

      final ref = FirebaseDatabase.instance.ref('schedules');
      await ref.push().set({
        'type': 'VITAMIN',
        'scheduled_at': scheduledDateTime.toIso8601String(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Vitamin scheduled at ${picked.format(context)}')),
      );
    }
  }

  void removeScheduledTime(int index) {
    setState(() {
      scheduledTimes.removeAt(index);
    });
  }

  @override
  void dispose() {
    vitaminTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final buttonColor = isDispensing ? Colors.red : Colors.green;
    final buttonText = isDispensing ? 'Stop Dispense' : 'Dispense Now';

    return Scaffold(
      backgroundColor: const Color(0xFFFBEAFF), // light purple-pink
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text('Vitamin Control'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: const Color(0xFFF9F6FF),
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4)),
                ],
              ),
              child: Column(
                children: [
                  const Text(
                    'CURRENT VITAMIN STATUS',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.purple,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                        children: [
                          const Text('Next Dose', style: TextStyle(fontSize: 14)),
                          Text(
                            scheduledTimes.isEmpty
                                ? 'Not scheduled'
                                : scheduledTimes.first.format(context),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Dose Amount', style: TextStyle(fontSize: 14)),
                          Text(
                            '${dose.toStringAsFixed(1)} ml',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),

            const Text(
              'VITAMIN SCHEDULE',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.purple,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 8),

            if (scheduledTimes.isEmpty)
              const Text(
                'No vitamin times scheduled',
                style: TextStyle(color: Colors.grey, fontSize: 16),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: scheduledTimes.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(
                      scheduledTimes[index].format(context),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => removeScheduledTime(index),
                    ),
                  );
                },
              ),

            const SizedBox(height: 16),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: pickScheduleTime,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: const Text(
                    'Add Schedule',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (isDispensing) {
                      stopDispensing();
                      sendCommandToFirebase("STOP");
                    } else {
                      startDispensing();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: buttonColor,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text(
                    buttonText,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),
            const Text(
              'VITAMIN DOSE (ml)',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.purple,
                fontSize: 16,
              ),
            ),
            Slider(
              activeColor: Colors.purple,
              value: dose,
              min: 1,
              max: 10,
              divisions: 9,
              label: '${dose.toStringAsFixed(1)} ml',
              onChanged: (value) {
                setState(() => dose = value);
              },
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Automatic Dispensing',
                  style: TextStyle(fontSize: 16),
                ),
                Switch(
                  value: automaticDispensing,
                  onChanged: (val) {
                    setState(() {
                      automaticDispensing = val;
                    });
                  },
                  activeColor: Colors.purple,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

package com.example.newcontroller

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
